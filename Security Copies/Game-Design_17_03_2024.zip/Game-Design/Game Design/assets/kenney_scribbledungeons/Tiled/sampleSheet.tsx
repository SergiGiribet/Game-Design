<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="tilesheet" tilewidth="64" tileheight="64" tilecount="154" columns="14">
 <image source="../Tilesheet/tilesheet.png" width="896" height="704"/>
</tileset>
